-- -------------------   << Empresa de Vendas (V3)  >>   -------------------
--
--                    SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 11/03/2020
-- Autor(es) ..............: Rogério S. dos Santos Júnior
-- Banco de Dados .........: MySQL 8.0
-- Banco de Dados(nome) ...: aula1exer2Evolucao3
-- 
-- Data Ultima Alteracao ..: 18/03/2020
--   => Remoção do DROP TABLE da tabela inserido
--   => Remoção do DROP TABLE da tabela supervisiona
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- ------------------------------------------------------------------------

USE aula1exer2Evolucao3;

DROP TABLE contem;
DROP TABLE telefone;
DROP TABLE VENDA;
DROP TABLE PRODUTO;
DROP TABLE AREA;
DROP TABLE EMPREGADO;
DROP TABLE GERENTE;
DROP TABLE PESSOA;
