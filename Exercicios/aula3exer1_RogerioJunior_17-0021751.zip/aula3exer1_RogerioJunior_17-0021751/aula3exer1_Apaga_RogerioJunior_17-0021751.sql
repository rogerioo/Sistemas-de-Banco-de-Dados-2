-- -------------------------------------------   << Escala de Plantonistas >>   --------------------------------------------
--
--                                                 SCRIPT DE APAGAR (DDL)                                                 
-- 
-- Data Criacao ...........: 23/03/2020
-- Autor(es) ..............: Rogério S. dos Santos Júnior
-- Banco de Dados .........: MySQL 8.0
-- Banco de Dados(nome) ...: aula3exer1
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
-- 
-- ------------------------------------------------------------------------------------------------------------------------

USE aula3exer1;

DROP TABLE alocado;
DROP TABLE possui;
DROP TABLE SETOR;
DROP TABLE PLANTONISTA;
DROP TABLE ESPECIALIDADE;
