-- -------------------------------------------   << Aula 04 - Extra 01 >>   --------------------------------------------
--
--                                                 SCRIPT DE APAGAR (DDL)                                                 
-- 
-- Data Criação ...........: 30/03/2020
-- Autor(es) ..............: Rogério S. dos Santos Júnior
-- Banco de Dados .........: MySQL 8.0
-- Banco de Dados(nome) ...: aula4extra1
-- 
-- PROJETO => 01 Base de Dados
--         => 02 Tabelas
-- 
-- ------------------------------------------------------------------------------------------------------------------------

USE aula4extra1;

DROP TABLE CIDADE;
DROP TABLE ESTADO;
